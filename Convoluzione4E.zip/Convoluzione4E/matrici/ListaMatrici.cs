using SixLabors.ImageSharp;
using SixLabors.ImageSharp.PixelFormats;

public class ListaMatrici
{
    public List<Matrice> listaMatriciP;
    private immagine img;

    public ListaMatrici(immagine i)
    {
        listaMatriciP = new List<Matrice>();
        img=i;
        string s = "";
        int[,] contrasto = new int[3, 3];
        contrasto[0, 0] = 0;
        contrasto[0, 1] = -1;
        contrasto[0, 2] = 0;
        contrasto[1, 0] = -1;
        contrasto[1, 1] = 5;
        contrasto[2, 1] = -1;
        contrasto[2, 0] = 0;
        contrasto[2, 1] = -1;
        contrasto[2, 2] = 0;
        s = "contrasto";
        Matrice mContrasto = new Matrice(contrasto, i, s);
        listaMatriciP.Add(mContrasto);

        int[,] sfocatura = new int[3, 3];
        sfocatura[0, 0] = 1;
        sfocatura[0, 1] = 1;
        sfocatura[0, 2] = 1;
        sfocatura[1, 0] = 1;
        sfocatura[1, 1] = 1;
        sfocatura[2, 1] = 1;
        sfocatura[2, 0] = 1;
        sfocatura[2, 1] = 1;
        sfocatura[2, 2] = 1;
        s = "sfocatura";
        Matrice mSfocatura = new Matrice(sfocatura, i, s);
        listaMatriciP.Add(mSfocatura);

        int[,] eBordi = new int[3, 3];
        sfocatura[0, 0] = 0;
        sfocatura[0, 1] = 0;
        sfocatura[0, 2] = 0;
        sfocatura[1, 0] = -1;
        sfocatura[1, 1] = 1;
        sfocatura[2, 1] = 0;
        sfocatura[2, 0] = 0;
        sfocatura[2, 1] = 0;
        sfocatura[2, 2] = 0;
        s = "Evidenzazione Bordi";
        Matrice mEBordi = new Matrice(eBordi, i, s);
        listaMatriciP.Add(mEBordi);

        int[,] iBordi = new int[3, 3];
        sfocatura[0, 0] = 0;
        sfocatura[0, 1] = 1;
        sfocatura[0, 2] = 0;
        sfocatura[1, 0] = 1;
        sfocatura[1, 1] = -4;
        sfocatura[2, 1] = 1;
        sfocatura[2, 0] = 0;
        sfocatura[2, 1] = 1;
        sfocatura[2, 2] = 0;
        s = "Individuazione Bordi";
        Matrice mIBordi = new Matrice(iBordi, i, s);
        listaMatriciP.Add(mIBordi);

        int[,] bassoRilievo = new int[3, 3];
        sfocatura[0, 0] = -2;
        sfocatura[0, 1] = -1;
        sfocatura[0, 2] = 0;
        sfocatura[1, 0] = -1;
        sfocatura[1, 1] = 1;
        sfocatura[2, 1] = 1;
        sfocatura[2, 0] = 0;
        sfocatura[2, 1] = 1;
        sfocatura[2, 2] = 2;
        s = "Basso Rilievo";
        Matrice mBassoRilievo = new Matrice(bassoRilievo, i, s);
        listaMatriciP.Add(mBassoRilievo);
    }
}