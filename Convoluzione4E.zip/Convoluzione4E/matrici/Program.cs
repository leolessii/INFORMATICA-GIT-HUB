﻿using SixLabors.ImageSharp;
using SixLabors.ImageSharp.ColorSpaces;
using SixLabors.ImageSharp.Processing;
using SixLabors.ImageSharp.Advanced;
using SixLabors.ImageSharp.PixelFormats;
using System.Dynamic;
internal class Program
{
    public static immagine img;
    public static ListaMatrici lstm;
    private static void Main(string[] args)
    {
        Console.WriteLine("paste the name and format of the image");
        string name = Console.ReadLine();

        img = new immagine(name);
        lstm = new ListaMatrici(img);

        bool correct = false;
        int Ichoice = 0;
        while(correct == false)
        {
            try 
            {
                Console.WriteLine("write: \n 1 to chose a matrix to apply on the image \n 2 to create a matrix");
                string Schoice = Console.ReadLine();
                Ichoice = Convert.ToInt32(Schoice);
                correct = true;
                break;
            }
            catch (Exception ex)
            {
                correct = false;
                break;
            }
        }

        if(Ichoice == 1)
        {
            for (int i = 0;i<lstm.listaMatriciP.Count; i++)
            {
                Console.WriteLine(i.ToString()+ " " + lstm.listaMatriciP[i].ToString());
            }
            bool correctMatrix = false;
            int IchoiceMatrix = 0;
            Ichoice =0;
            while(correct == false)
            {
                try 
                {
                    Console.WriteLine("Write the number before the matrix to choose that matrix and aplly it on the image");
                    string Schoice = Console.ReadLine();
                    Ichoice = Convert.ToInt32(Schoice);
                    correct = true;
                }
                catch (Exception ex)
                {
                    correct = false;
                    break;
                }
            }
            for(int i = 0;i<lstm.listaMatriciP.Count; i++)
            {
                if(IchoiceMatrix == i)
                {
                    lstm.listaMatriciP[i].StartMatrice();
                }
            }
        }    
    }
}