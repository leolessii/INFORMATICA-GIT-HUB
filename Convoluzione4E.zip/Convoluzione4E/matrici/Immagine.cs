using SixLabors.ImageSharp;
using SixLabors.ImageSharp.PixelFormats;
    public class Immagine
    {
        public Image<Rgba32> image;
        public Color colorTaken;

        public Immagine(string nameImage)
        {
            image = Image.Load<Rgba32>(nameImage);
        }

        public Color GetColor(int x, int y)
        {
            colorTaken = image[x, y];
            return colorTaken;
        }

        public void SetColor(int x, int y, Color color)
        {
            image[x, y] = color;
        }

        public void Save(string path)
        {
                image.SaveAsPng($"{path}.png");
        }

        public int GetWidth()
        {
            return image.Width;
        }

        public int GetHeight()
        {
            return image.Height;
        }
    }
