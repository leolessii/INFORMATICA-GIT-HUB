﻿using Matrici_Core;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Matrici_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Matrice ma;
        Immagine img;
        List<Matrice> matriciPreImpostate = new List<Matrice>();

        public MainWindow()
        {
            InitializeComponent();
            //inizializza matrice ma
            int[,] i = new int[3, 3];
            ma = new Matrice(i, img, "ma");
        }

        private void btnPercorsoFile_Click(object sender, RoutedEventArgs e)
        {
            string s = "";
            Immagine i = new Immagine(txtPercorsoFile.Text);
            int[,] contrasto = new int[3, 3];
            contrasto[0, 0] = 0;
            contrasto[0, 1] = -1;
            contrasto[0, 2] = 0;
            contrasto[1, 0] = -1;
            contrasto[1, 1] = 5;
            contrasto[2, 1] = -1;
            contrasto[2, 0] = 0;
            contrasto[2, 1] = -1;
            contrasto[2, 2] = 0;
            s = "contrasto";
            Matrice mContrasto = new Matrice(contrasto, i, s);
            matriciPreImpostate.Add(mContrasto);

            int[,] sfocatura = new int[3, 3];
            sfocatura[0, 0] = 1;
            sfocatura[0, 1] = 1;
            sfocatura[0, 2] = 1;
            sfocatura[1, 0] = 1;
            sfocatura[1, 1] = 1;
            sfocatura[2, 1] = 1;
            sfocatura[2, 0] = 1;
            sfocatura[2, 1] = 1;
            sfocatura[2, 2] = 1;
            s = "sfocatura";
            Matrice mSfocatura = new Matrice(sfocatura, i, s);
            matriciPreImpostate.Add(mSfocatura);

            int[,] eBordi = new int[3, 3];
            sfocatura[0, 0] = 0;
            sfocatura[0, 1] = 0;
            sfocatura[0, 2] = 0;
            sfocatura[1, 0] = -1;
            sfocatura[1, 1] = 1;
            sfocatura[2, 1] = 0;
            sfocatura[2, 0] = 0;
            sfocatura[2, 1] = 0;
            sfocatura[2, 2] = 0;
            s = "Evidenzazione Bordi";
            Matrice mEBordi = new Matrice(eBordi, i, s);
            matriciPreImpostate.Add(mEBordi);

            int[,] iBordi = new int[3, 3];
            sfocatura[0, 0] = 0;
            sfocatura[0, 1] = 1;
            sfocatura[0, 2] = 0;
            sfocatura[1, 0] = 1;
            sfocatura[1, 1] = -4;
            sfocatura[2, 1] = 1;
            sfocatura[2, 0] = 0;
            sfocatura[2, 1] = 1;
            sfocatura[2, 2] = 0;
            s = "Individuazione Bordi";
            Matrice mIBordi = new Matrice(iBordi, i, s);
            matriciPreImpostate.Add(mIBordi);

            int[,] bassoRilievo = new int[3, 3];
            sfocatura[0, 0] = -2;
            sfocatura[0, 1] = -1;
            sfocatura[0, 2] = 0;
            sfocatura[1, 0] = -1;
            sfocatura[1, 1] = 1;
            sfocatura[2, 1] = 1;
            sfocatura[2, 0] = 0;
            sfocatura[2, 1] = 1;
            sfocatura[2, 2] = 2;
            s = "Basso Rilievo";
            Matrice mBassoRilievo = new Matrice(bassoRilievo, i, s);
            matriciPreImpostate.Add(mBassoRilievo);

            lstMatrici.ItemsSource = matriciPreImpostate;
            string imagePath = txtPercorsoFile.Text;
            imgIniziale.Source = new BitmapImage(new Uri(imagePath, UriKind.Relative));
            //scopri perchè non mette l'immagine
        }

        private void lstMatrici_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(lstMatrici.SelectedItems != null)
            {
                ma = lstMatrici.SelectedItem as Matrice;
            }
        }

        private void btnApplicaMatrice_Click(object sender, RoutedEventArgs e)
        {
            ma.MatriceP = (lstMatrici.SelectedItem as Matrice).MatriceP;
            ma.Name = (lstMatrici.SelectedItem as Matrice).Name;
            ma.img = (lstMatrici.SelectedItem as Matrice).img;
            ma.StartMatrice();
            string imagePath = txtPercorsoFile.Text;
            ImgFinale.Source = new BitmapImage(new Uri(imagePath, UriKind.Relative));
            ImgFinale.Visibility = Visibility.Visible;  
        }
    }
}