﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.PixelFormats;

namespace Matrici_Core
{
    public class Matrice
    {
        private string _name;
        private int[,] _matriceP;
        private int _moltiplicatore;
        private Immagine _img;
        private int _widht;
        private int _height;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public int[,] MatriceP
        {
            get { return _matriceP; }
            set
            {
                _matriceP = value;
            }
        }

        public Immagine img
        {
            get { return _img; }
            set { _img = value; }
        }

        public Matrice(int[,] m, Immagine i, string Name)
        {
            _matriceP = m;
            _img = i;
            _moltiplicatore = _matriceP[1, 1];
            _name = Name;
        }

        private Rgba32 GetNewColorPixel(int x, int y)
        {
            int newRed;
            int newGreen;
            int newBlue;
            int newAlpha;
            Rgba32 color;

            color = _img.GetColor(x, y);
            newRed = (color.R * _moltiplicatore);
            if (newRed > 255)
            {
                newRed = 255;
            }
            color.R = Convert.ToByte(newRed);
            newGreen = (color.G * _moltiplicatore);
            if (newGreen > 255)
            {
                newGreen = 255;
            }
            color.G = Convert.ToByte(newGreen);
            newBlue = (color.B * _moltiplicatore);
            if (newBlue > 255)
            {
                newBlue = 255;
            }
            color.B = Convert.ToByte(newBlue);
            newAlpha = (color.A * _moltiplicatore);
            if (newAlpha > 255)
            {
                newAlpha = 255;
            }
            color.A = Convert.ToByte(newAlpha);

            return color;
        }

        private void MatriceWidth(int y)
        {
            int[] pixel = [1, 1];
            int x = 1;
            for (int i = 1; i <= _img.GetWidth()-2; i++)
            {
                _img.SetColor(pixel[x], pixel[y], GetNewColorPixel(x, y));
                x++;
            }
        }

        private void MatriceHeight()
        {
            int[] pixel = [1, 1];
            int y = 1;
            for (int i = 1; i <=_img.GetHeight()-2; i++)
            {
                MatriceWidth(y);
                y++;
            }
        }

        public void StartMatrice()
        {
            MatriceHeight();
            _img.Save("risultato");
        }

        public override string ToString()
        {
            return _name;
        }
    }
}
