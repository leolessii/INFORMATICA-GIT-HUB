﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.PixelFormats;

namespace Matrici_Core
{
    public class Matrice
    {
        private string name;
        private int[,] matrice;
        private int moltiplicatore;
        private Immagine img;
        private int Width;
        private int Height;

        public Matrice(int[,] m, Immagine i, string Name)
        {
            matrice = m;
            img = i;
            moltiplicatore = matrice[1, 1];
            name = Name;
        }

        private Rgba32 GetNewColorPixel(int x, int y, Rgba32[,] coloriImmgagine)
        {
            byte newRed = 0;
            byte newGreen = 0;
            byte newBlue = 0;
            byte newAlpha = 0;
            Rgba32 color;
            Rgba32[,] colori = coloriImmgagine;

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    newRed += (byte)(colori[j, i].R * Convert.ToByte(matrice[j, i]));
                    newGreen += (byte)(colori[j, i].R * Convert.ToByte(matrice[j, i]));
                    newBlue += (byte)(colori[j, i].R * Convert.ToByte(matrice[j, i]));
                    newAlpha += (byte)(colori[j, i].R * Convert.ToByte(matrice[j, i]));
                }
            }
            color.R = newRed;
            color.G = newGreen;
            color.B = newBlue;
            color.A = newAlpha;
            return color;
        }


        private void MatriceWidth(int y)
        {
            int[] pixel = [1, 1];
            int x = 1;
            Rgba32[,] coloriImmgagine = new Rgba32[3, 3];

            for (int i = 0; i <= Width - 1; i++)
            {
                coloriImmgagine[0, 0] = img.GetColor(x - 1, y - 1);
                coloriImmgagine[0, 1] = img.GetColor(x, y - 1);
                coloriImmgagine[0, 2] = img.GetColor(x + 1, y - 1);
                coloriImmgagine[1, 0] = img.GetColor(x - 1, y);
                coloriImmgagine[1, 1] = img.GetColor(x, y);
                coloriImmgagine[1, 2] = img.GetColor(x + 1, y);
                coloriImmgagine[2, 0] = img.GetColor(x - 1, y + 1);
                coloriImmgagine[2, 1] = img.GetColor(x, y + 1);
                coloriImmgagine[2, 2] = img.GetColor(x + 1, y + 1);
                img.SetColor(pixel[x], pixel[y], GetNewColorPixel(x, y, coloriImmgagine));
                x++;
            }
        }

        private void MatriceHeight()
        {
            int[] pixel = [1, 1];
            int y = 1;
            for (int i = 0; i <= Height - 1; i++)
            {
                MatriceWidth(y);
                y++;
            }
        }

        public void StartMatrice(string s)
        {
            MatriceHeight();
            img.Save(s);
        }

        public override string ToString()
        {
            return name;
        }
    }
}
